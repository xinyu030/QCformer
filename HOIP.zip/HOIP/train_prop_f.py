import os
import torch
import numpy as np

import ignite
from ignite.engine import (
    Events,
    create_supervised_evaluator,
    create_supervised_trainer,
)
from ignite.utils import convert_tensor
# from ignite.contrib.handlers.tqdm_logger import ProgressBar
from ignite.metrics import Loss, MeanAbsoluteError
from ignite.handlers import Checkpoint, DiskSaver, TerminateOnNan
from sklearn.metrics import roc_auc_score

# from data import get_train_val_test
from data import prepare_data_HOIP, prepare_data_NMSE
from quotientcomplex import get_train_test_loader
from pmodel import QCformer

import yaml
import argparse

import pickle




# torch config
torch.set_default_dtype(torch.float32)
device = "cpu"
if torch.cuda.is_available():
    device = torch.device("cuda")



def count_parameters(model):
    total_params = 0
    for parameter in model.parameters():
        total_params += parameter.element_size() * parameter.nelement()
    for parameter in model.buffers():
        total_params += parameter.element_size() * parameter.nelement()
    total_params = total_params / 1024 / 1024
    print(f"Total Trainable Params: {total_params} MB")
    return total_params



def group_decay(model):
    """Omit weight decay from bias and batchnorm params."""
    decay, no_decay = [], []

    for name, p in model.named_parameters():
        if "bias" in name or "bn" in name or "norm" in name:
            no_decay.append(p)
        else:
            decay.append(p)

    return [
        {"params": decay},
        {"params": no_decay, "weight_decay": 0},
    ]


def load_config(config_path):
    with open(config_path, 'r') as file:
        config = yaml.safe_load(file)
    return config


def print_dict(d, indent=0):
    for key, value in d.items():
        if isinstance(value, dict):
            print('  ' * indent + str(key) + ':')
            print_dict(value, indent + 1)
        else:
            print('  ' * indent + str(key) + ': ' + str(value))


def load_dataset(config,dataset,prop,fold,batch_size,file_path,pretrain_data=False):
    print(file_path)
    if os.path.exists(file_path):
        print('Data file exists, loading data from pickle file...')
        with open(file_path, 'rb') as handle:
            data = pickle.load(handle)
        if pretrain_data:
            train_loader = data['train_loader']
            val_loader = data['val_loader']
            test_loader = data['test_loader']
            prepare_batch = data['prepare_batch']
            mean_train = data['mean_train']
            std_train = data['std_train']
            n_test = len(test_loader.dataset)
            print('Data loaded!')
            return train_loader,val_loader,test_loader,prepare_batch,mean_train,std_train,n_test
        else:
            train_loader = data['train_loader']
            test_loader = data['test_loader']
            prepare_batch = data['prepare_batch']
            mean_train = data['mean_train']
            std_train = data['std_train']
            n_test = len(test_loader.dataset)
            print('Data loaded!')
            return train_loader,test_loader,prepare_batch,mean_train,std_train,n_test
    else:
        print('Data file does not exist, loading data from scratch...')
        if dataset == 'HOIP':
            df_train, df_test = prepare_data_HOIP(fold)
            train_loader,test_loader,prepare_batch,mean_train,std_train = get_train_test_loader(config,dataset,df_train,df_test,prop,batch_size)
            n_test = len(df_test)
        elif dataset == 'NMSE':
            df_train, df_test = prepare_data_NMSE(fold)
            train_loader,test_loader,prepare_batch,mean_train,std_train = get_train_test_loader(config,dataset,df_train,df_test,prop,batch_size)
            n_test = len(df_test)
        try: 
            data_to_pickle = {
            'train_loader': train_loader,
            'test_loader': test_loader,
            'prepare_batch': prepare_batch,
            'mean_train': mean_train,
            'std_train': std_train
        }
            with open(file_path, 'wb') as handle:
                pickle.dump(data_to_pickle, handle, protocol=pickle.HIGHEST_PROTOCOL)
        except:
            print('Failed to save data to pickle file')

        print('Dataset loaded!')
        return train_loader,test_loader,prepare_batch,mean_train,std_train,n_test



def pretrain(config_path,pretrain_path):
    config = load_config(config_path)
    print_dict(config)

    dataset = config['training']['dataset']
    epoch = config['training']['epoch']
    learning_rate = config['training']['learning_rate']
    batch_size = config['training']['batch_size']
    weight_decay = float(config['training']['weight_decay'])
    split_seed = config['training']['split_seed']
    model_criterion = config['model']['p-criterion']

    deterministic = False

    file_path = 'pretrain/Jarvis_bandgap_opt.pickle'
    train_loader,val_loader,test_loader,prepare_batch,mean_train,std_train,n_test = load_dataset(config, dataset, None, None, batch_size, file_path, pretrain_data=True)
    print('std_train:', std_train)
    print('------------------------------------')
    print('Start Pretraining...')

    ignite.utils.manual_seed(split_seed)
    
    net = QCformer(config)
    count_parameters(net)
    net.to(device)
    if model_criterion == 'mse':
        criterion = torch.nn.MSELoss()
    elif model_criterion == 'mae':
        criterion = torch.nn.L1Loss()
    params = group_decay(net)
    optimizer = torch.optim.AdamW(params, lr=learning_rate, weight_decay=weight_decay)
    scheduler = torch.optim.lr_scheduler.OneCycleLR(optimizer, max_lr=learning_rate, steps_per_epoch=len(train_loader), epochs=epoch, pct_start=0.3)

    metrics = {"loss": Loss(criterion), "mae": MeanAbsoluteError() * std_train}

    trainer = create_supervised_trainer(
        net,
        optimizer,
        criterion,
        prepare_batch=prepare_batch,
        device=device,
        deterministic=deterministic,
    )

    val_evaluator = create_supervised_evaluator(
        net,
        metrics=metrics,
        prepare_batch=prepare_batch,
        device=device,
    )

    # Ignite event handlers:
    trainer.add_event_handler(Events.EPOCH_COMPLETED, TerminateOnNan())

    # Apply learning rate scheduler
    trainer.add_event_handler(
        Events.ITERATION_COMPLETED, lambda engine: scheduler.step()
    )

    best_val_loss = float('inf')
    best_model_state = None

    @trainer.on(Events.EPOCH_COMPLETED)
    def validate_and_save_best_model(engine):
        """Validate the model and save the best one."""
        val_evaluator.run(val_loader)
        val_metrics = val_evaluator.state.metrics
        val_loss = val_metrics["loss"]

        nonlocal best_val_loss, best_model_state
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            best_model_state = net.state_dict()
            print(f"New best model with validation loss: {val_loss:.4f}")
        
        print(f"Epoch {engine.state.epoch} Validation Loss: {val_loss:.4f}, MAE: {val_metrics['mae']:.4f}")

    trainer.run(train_loader, max_epochs=epoch)

    # Save the best model
    if best_model_state is not None:
        model_save_path = pretrain_path
        os.makedirs(os.path.dirname(model_save_path), exist_ok=True)
        torch.save(best_model_state, model_save_path)
        print(f"Best model saved at {model_save_path}")


    print("Pretraining completed.")


def finetune(config_path,pretrain_path):
    config = load_config(config_path)
    # print(config)
    print_dict(config)

    dataset = config['training']['dataset']
    epoch = config['training']['epoch']
    learning_rate = config['training']['learning_rate']
    batch_size = config['training']['batch_size']
    weight_decay = float(config['training']['weight_decay'])
    prop = config['training']['property']
    fold = config['training']['fold']
    write_predictions = config['training']['write_predictions']
    model_criterion = config['model']['criterion']
    task = config['training']['task']

    if write_predictions:
        output_dir = 'results-'+ dataset + '/' + dataset + '-' + str(fold)
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)

    deterministic = False
    
    finetune_path = 'data/' + dataset + '/' + dataset + '-' + str(fold) + '-' + str(batch_size) + '.pickle'
    train_loader,test_loader,prepare_batch,mean_train,std_train,n_test = load_dataset(config,dataset,prop,fold,batch_size,finetune_path,pretrain_data=False)
    print('mean_train:',mean_train)
    print('std_train:',std_train)
    print('n_test:',n_test)
    print('------------------------------------')
    print("Start Finetuning...")
    net = QCformer(config)
    net.load_state_dict(torch.load(pretrain_path))  # Load pretrained weights
    count_parameters(net)
    net.to(device)


    if model_criterion == 'mse':
        criterion = torch.nn.MSELoss()
    elif model_criterion == 'mae':
        criterion = torch.nn.L1Loss()
    params = group_decay(net)
    optimizer = torch.optim.AdamW(params,lr=learning_rate,weight_decay=weight_decay)
    scheduler = torch.optim.lr_scheduler.OneCycleLR(optimizer, max_lr=learning_rate, steps_per_epoch=len(train_loader), epochs=epoch,pct_start=0.3)
    

    metrics = {"loss": Loss(criterion), "mae": MeanAbsoluteError() * std_train, "neg_mae": -1.0 * MeanAbsoluteError() * std_train}
    
    trainer = create_supervised_trainer(
        net,
        optimizer,
        criterion,
        prepare_batch=prepare_batch,
        device=device,
        deterministic=deterministic,
    )

    train_evaluator = create_supervised_evaluator(
        net,
        metrics=metrics,
        prepare_batch=prepare_batch,
        device=device,
    )

    test_evaluator = create_supervised_evaluator(
        net,
        metrics=metrics,
        prepare_batch=prepare_batch,
        device=device,
    )
    
    # ignite event handlers:
    trainer.add_event_handler(Events.EPOCH_COMPLETED, TerminateOnNan())

    # apply learning rate scheduler
    trainer.add_event_handler(
        Events.ITERATION_COMPLETED, lambda engine: scheduler.step()
    )
    
    '''
    # model checkpointing
    to_save = {"model": net,"optimizer": optimizer,"lr_scheduler": scheduler,"trainer": trainer}
    handler = Checkpoint(to_save, DiskSaver('saved/' + model_detail, create_dir=True, require_empty=False),
            n_saved=2, global_step_transform=lambda *_: trainer.state.epoch)
    trainer.add_event_handler(Events.EPOCH_COMPLETED, handler)
    
    # evaluate save
    to_save = {"model": net}
    handler = Checkpoint(to_save, DiskSaver('saved/' + model_detail, create_dir=True, require_empty=False),
            n_saved=2,filename_prefix='best',score_name="neg_mae",global_step_transform=lambda *_: trainer.state.epoch)
    val_evaluator.add_event_handler(Events.EPOCH_COMPLETED, handler)
    '''
    history = {
        "train": {m: [] for m in metrics.keys()},
        "test": {m: [] for m in metrics.keys()},
    }
    
    # collect evaluation performance
    @trainer.on(Events.EPOCH_COMPLETED)
    def log_results(engine):
        """Print training and validation metrics to console."""
        test_evaluator.run(test_loader)
        tmetrics = test_evaluator.state.metrics
        for metric in metrics.keys():
            tm = tmetrics[metric]
            if metric == "roccurve":
                tm = [k.tolist() for k in tm]
            if isinstance(tm, torch.Tensor):
                tm = tm.cpu().numpy().tolist()

            history["test"][metric].append(tm)

        
        
        epoch_num = len(history["test"]["loss"])
        if epoch_num % 10 == 0:
            # train
            train_evaluator.run(train_loader)
            tmetrics = train_evaluator.state.metrics
            for metric in metrics.keys():
                tm = tmetrics[metric]
                if metric == "roccurve":
                    tm = [k.tolist() for k in tm]
                if isinstance(tm, torch.Tensor):
                    tm = tm.cpu().numpy().tolist()

                history["train"][metric].append(tm)
            
        else:
            tmetrics = {}
            tmetrics['mae'] = -1
            #test_metrics = {}
            #test_metrics['mae'] = -1
        
        if task == 'regression':
            test_mae = 0
            if epoch_num==epoch:
                # test
                net.eval()
                if write_predictions:
                    output_file = output_dir + '/test_prediction.csv'
                    with open(output_file, 'w') as f:
                        # f.write("jid,target,prediction\n")
                        f.write("target, prediction\n")
                        with torch.no_grad():  
                            # jids = test_loader.dataset.df['jid'].tolist()
                            for idx, dat in enumerate(test_loader):
                                g,target = dat
                                target=target.to(device)
                                out_data = net(g.to(device))
                                pre1 = target.view(-1).tolist()
                                pre2 = out_data.view(-1).tolist() 
                                # If the final batch of the data loader contains only one sample,
                                # target and out_data might become scalar tensors (e.g., torch.Size([])) 
                                # instead of tensors with a batch dimension (e.g., torch.Size([1])).
                                # In this case, we need to use .view(-1) to convert them to 1D tensors.
                                
                                for i, (true_val, pred_val) in enumerate(zip(pre1, pre2)):
                                    true_val_original = true_val * std_train + mean_train
                                    pred_val_original = pred_val * std_train + mean_train
                                    
                                    # f.write(f"{jids[idx * len(pre1) + i]}, {true_val_original:.6f}, {pred_val_original:.6f}\n")
                                    f.write(f"{true_val_original:.6f}, {pred_val_original:.6f}\n")
                with torch.no_grad():  
                    for dat in test_loader:
                        g,target = dat
                        target=target.to(device)
                        out_data = net(g.to(device))
                        #print(target.shape,out_data.shape)
                        test_mae = test_mae + torch.abs(target-out_data).sum().data.item()
                    


            if epoch_num<epoch:
                print('epoch:',epoch_num,f"Train_MAE: {tmetrics['mae']:.4f}")
            else:
                print('epoch:',epoch_num,f"Train_MAE: {tmetrics['mae']:.4f}","Test MAE",test_mae*std_train/n_test)
    
    # @trainer.on(Events.EPOCH_COMPLETED)
    # def validate_and_save_best_model(engine):
    #     if engine.state.epoch == epoch:                
    #         best_model_state = net.state_dict()
    #         model_save_path = f"finetune/NMSE_best_model-test.pth"
    #         # create the directory if it does not exist
    #         if not os.path.exists(os.path.dirname(model_save_path)):
    #             os.makedirs(os.path.dirname(model_save_path))
    #         # cover the previous best model
    #         torch.save(best_model_state, model_save_path)
    #         print(f"Best model saved at {model_save_path}")

    trainer.run(train_loader, max_epochs=epoch)

    
    
def main():
    parser = argparse.ArgumentParser(description="Run model with config file")
    parser.add_argument('config_file', type=str, help='Path to the config file')
    args = parser.parse_args()
    
    import time
    start_time = time.time()

    # pretrain(args.config_file,'pretrain/Jarvis_best_model.pth')
    finetune(args.config_file, 'pretrain/Jarvis_best_model.pth')

    end_time = time.time()
    elapsed_time = end_time - start_time
    hours = elapsed_time // 3600
    minutes = (elapsed_time % 3600) // 60
    seconds = elapsed_time % 60
    print(f"Elapsed time: {int(hours)} hrs, {int(minutes)} mins, {seconds:.2f} secs")


    
def check_gpu():
    if torch.cuda.is_available():
        device = torch.device('cuda')
        print('The code uses GPU...')
    else:
        device = torch.device('cpu')
        print('The code uses CPU!!!')


if __name__ == '__main__':
    main() 
    # check_gpu()





        
    