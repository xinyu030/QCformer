from jarvis.db.figshare import data as jdata
import math
import numpy as np
import random
import pandas as pd
from sklearn.model_selection import KFold
import os
import pickle
from jarvis.core.atoms import Atoms
from pymatgen.core import Structure
from jarvis.core.atoms import pmg_to_atoms

def get_id_train_val_test(
    total_size=1000,
    split_seed=123,
    train_ratio=None,
    val_ratio=0.1,
    test_ratio=0.1,
    n_train=None,
    n_test=None,
    n_val=None,
    keep_data_order=False,
):
    """Get train, val, test IDs."""
    if (
        train_ratio is None
        and val_ratio is not None
        and test_ratio is not None
    ):
        if train_ratio is None:
            assert val_ratio + test_ratio < 1
            train_ratio = 1 - val_ratio - test_ratio
            print("Using rest of the dataset except the test and val sets.")
        else:
            assert train_ratio + val_ratio + test_ratio <= 1
    # indices = list(range(total_size))
    if n_train is None:
        n_train = int(train_ratio * total_size)
    if n_test is None:
        n_test = int(test_ratio * total_size)
    if n_val is None:
        n_val = int(val_ratio * total_size)
    ids = list(np.arange(total_size))
    if not keep_data_order:
        random.seed(split_seed)
        random.shuffle(ids)
    if n_train + n_val + n_test > total_size:
        raise ValueError(
            "Check total number of samples.",
            n_train + n_val + n_test,
            ">",
            total_size,
        )

    id_train = ids[:n_train]
    id_val = ids[-(n_val + n_test) : -n_test]  
    id_test = ids[-n_test:]
    return id_train, id_val, id_test




def prepare_data_moduli(typ):
    if typ[0]=='b':
        typ1 = 'bulk'
    else:
        typ1 = 'shear'
    import pickle
    filename = 'data/' + typ1 + '_megnet_train.pkl'
    d_train = pickle.load(open(filename,'rb'))
    
    filename = 'data/' + typ1 + '_megnet_val.pkl'
    d_val = pickle.load(open(filename,'rb'))
    
    filename = 'data/' + typ1 + '_megnet_test.pkl'
    d_test = pickle.load(open(filename,'rb'))
    
    property = typ1 + ' modulus'
    for item in d_train:
        item[property] = item[property].item()
    for item in d_val:
        item[property] = item[property].item()
    for item in d_test:
        item[property] = item[property].item()
    return d_train,d_val,d_test


def get_train_val_test(dataset,property,split_seed):
    if property=='bulk modulus' or property=='shear modulus':
        dataset_train,dataset_val,dataset_test = prepare_data_moduli(property)
    
    else:
        if dataset=='mp':
            d = jdata('megnet')
        elif dataset=='jarvis':
            d = jdata('cfid_3d')
    
        # extract specific data
        all_targets = []
        dat = []
        index = []
    
        for i in range(len(d)):
        # for i in range(500):
            if ( d[i][property] is not None and d[i][property] != "na" and not math.isnan(d[i][property]) ):
                index.append(i)
                all_targets.append(d[i][property])
                dat.append(d[i])
    
        # split train,val,test
        if dataset=='jarvis':
            id_train, id_val, id_test = get_id_train_val_test( total_size=len(index), split_seed=split_seed,
                train_ratio=0.8,val_ratio=0.1,test_ratio=0.1)
        elif dataset=='mp':
            id_train, id_val, id_test = get_id_train_val_test( total_size=len(index), split_seed=split_seed,
                train_ratio=0.866564,val_ratio=0.072214,test_ratio=0.061223)
    
    
        dataset_train = [dat[x] for x in id_train]
        dataset_val = [dat[x] for x in id_val]
        dataset_test = [dat[x] for x in id_test]
    
    return dataset_train,dataset_val,dataset_test



def get_id_train_val_test_kfolds(
    total_size=1000,
    kfolds=10,
    seed=42,
):

    ids = list(np.arange(total_size))
    kf = KFold(n_splits=kfolds, shuffle=True) # can add random_state=seed
    id_train = []
    id_test = []
    for train_index, test_index in kf.split(ids):
        id_train.append(train_index)
        id_test.append(test_index)
    path = 'data/NMSE/' + str(kfolds) + '_folds.pkl'
    with open(path, 'wb') as f:
        pickle.dump({'id_train':id_train,'id_test':id_test}, f)

    return id_train, id_test



def process_cif_files(path, total_size=1346, output_file="processed_data.pkl"):
    # Properties to extract and store separately
    target_properties = [
        'Bandgap, HSE06 (eV)',
        'Bandgap, GGA (eV)',
        'Dielectric constant, electronic',
        'Dielectric constant, ionic',
        'Dielectric constant, total',
        'Refractive index',
        'Atomization energy (eV/atom)'
    ]
    
    ids = []
    atoms_list = []
    extracted_properties = {prop: [] for prop in target_properties}  # Store each property separately

    for i in range(1, total_size + 1):
        # Zero-padded file names from 0001.cif to 1346.cif
        cif_file = os.path.join(path, f"{str(i).zfill(4)}.cif")
        
        if os.path.exists(cif_file):
            try:
                # Extract atomic structure using jarvis-tools
                atom_data = Atoms.from_cif(cif_file)
                atoms_list.append(atom_data)
                
                # Initialize property values for this file
                file_properties = {prop: None for prop in target_properties}
                
                # Extract metadata (properties from comments)
                with open(cif_file, 'r') as f:
                    for line in f:
                        if line.startswith('#'):
                            # Parse lines with ':' to extract key-value pairs
                            if ':' in line:
                                key, value = line.strip('#').strip().split(':', 1)
                                key = key.strip()
                                value = value.strip()
                                
                                # Store the value if it's in the target properties
                                if key in target_properties:
                                    try:
                                        file_properties[key] = float(value)  # Convert to float
                                    except ValueError:
                                        print(f"Non-numeric value for {key} in {cif_file}: {value}")
                
                # Append the extracted values for this file
                for prop in target_properties:
                    extracted_properties[prop].append(file_properties[prop])
                
                ids.append(i)
            except Exception as e:
                print(f"Error processing {cif_file}: {e}")
                continue
        else:
            print(f"File {cif_file} not found.")
            continue

    # Combine atoms and properties into a single DataFrame
    df = pd.DataFrame({
        'id': ids,
        'atoms': atoms_list
    })

    # Add extracted properties as separate columns
    for prop in target_properties:
        df[prop] = extracted_properties[prop]

    # Save the DataFrame to a pickle file
    with open(output_file, "wb") as f:
        pickle.dump(df, f)
    
    print(f"Data successfully saved to {output_file}")
    return df


def prepare_data_HOIP(fold):
    total_size=1346
    path = 'data/HOIP/'
    hoip_pkl = os.path.join(path, 'HOIP_processed.pkl')
    folds_pkl = os.path.join(path, '10_folds.pkl')
    # Check if 'HOIP.csv' exists
    if os.path.exists(hoip_pkl):
        # If file exists, read it
        print(f"Loading {hoip_pkl}...")
        with open(hoip_pkl, "rb") as f:
            df = pickle.load(f)
    else:
        # If file doesn't exist, process .cif files
        print(f"{hoip_pkl} not found. Processing .cif files to create the DataFrame...")
        df = process_cif_files(path, total_size, hoip_pkl)

    # Load train and test splits from '10_folds.pkl'
    if not os.path.exists(folds_pkl):
        print(f"Creating {folds_pkl}...")
        get_id_train_val_test_kfolds(total_size=total_size,kfolds=10)
    print(f"Loading splits from {folds_pkl}...")
    with open(folds_pkl, 'rb') as f:
        splits = pickle.load(f)
    id_train = splits['id_train'][fold]
    id_test = splits['id_test'][fold]

    # Create train and test DataFrames
    df_train = df.iloc[id_train]
    df_test = df.iloc[id_test]

    return df_train, df_test


def prepare_data_NMSE(fold):
    total_size=624
    path = 'data/NMSE/'
    nmse_pkl = os.path.join(path, f'NMSE_processed.pkl')
    folds_pkl = os.path.join(path, '5_folds.pkl')
    # Check if 'xxxx.pkl' exists
    if os.path.exists(nmse_pkl):
        # If file exists, read it
        print(f"Loading {nmse_pkl}...")
        with open(nmse_pkl, "rb") as f:
            df = pickle.load(f)
    else:
        # If file doesn't exist, process raw file
        print(f"{nmse_pkl} not found. Processing raw file to create the DataFrame...")
        with open("data/NMSE/NMSE-716.pkl", "rb") as f:
            data = pickle.load(f) 
        subsampled_data = random.sample(data, total_size)
        print(f"Length of subsampled data: {len(subsampled_data)}")
        jid = []
        target = []
        atoms_list = []
        for d in subsampled_data:
            jid.append(d['jid'])
            target.append(d['dft-bandgap'])
            atoms_list.append(d['atoms'])
        idx = np.arange(len(subsampled_data))
        df = pd.DataFrame({'id': idx, 'jid':jid, 'atoms': atoms_list, 'dft-bandgap': target})
        with open(nmse_pkl, "wb") as f:
            pickle.dump(df, f)
        print(f"Data successfully saved to {nmse_pkl}")

    if not os.path.exists(folds_pkl):
        print(f"Creating {folds_pkl}...")
        get_id_train_val_test_kfolds(total_size=total_size,kfolds=5)
    print(f"Loading splits from {folds_pkl}...")
    with open(folds_pkl, 'rb') as f:
        splits = pickle.load(f)
    id_train = splits['id_train'][fold]
    id_test = splits['id_test'][fold]

    # Create train and test DataFrames
    df_train = df.iloc[id_train]
    df_test = df.iloc[id_test]

    return df_train, df_test



if __name__ == "__main__":
    # get_id_train_val_test_kfolds(total_size=624,kfolds=5)
    # df_train, df_test = prepare_data_NMSE(0)
    # print(df_train.head())

    # path = 'data/NMSE/'
    # hoip_pkl = os.path.join(path, 'HOIP_processed.pkl')
    # with open(hoip_pkl, "rb") as f:
    #     df = pickle.load(f)
    # print(df.head())
    # print(len(df)) #493

    df_train, df_test = prepare_data_HOIP(0)
    data0 = df_train.iloc[0]
    print(data0['atoms'])

 